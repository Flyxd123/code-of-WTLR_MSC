%% For convinience, we assume the order of the tensor is always 3;
clear;
clc


load E:\Code_work\dataset\UCI_3view;
cls_num=10;
for i=1:3
    X{i} =data{i}';
end
N=size(X{1},2);
gt=truth;


K = length(X); N = size(X{1},2); %sample number
%%Consteruct similarity matrix and corresponding tensor%%%
M=zeros(N,N,K);
for v=1:K
    tem = NormalizeData(X{v});
    sigma=0.6*optSigma(tem');
    options.KernelType = 'Gaussian';
    options.t = sigma;
    M(:,:,v) = constructKernel(tem',tem',options);
    D=diag(sum(M(:,:,v),2));
    L_rw=D^-1*M(:,:,v);
    T{v}=L_rw;  
end

re_our2=[];

la = [0.0001 0.001 0.01 0.1 0.5 1 5 10 50 100];
   la1=[0.01 0.1 0.3 0.5 1 5 10 15 50 100];
% for i=1:length(la1)
%     lambda = la1(i);
%     for j=1:length(la)
%         alpha = la(j);
%    for i=1:15
%         %%====Perform our====%%

        tic
        [P2 E con err] = ET_inter_intra(T,0.5,0.01); %ET_inter_intra(T,lambda,alpha);
        toc
        
        [pi,~]  = eigs(P2',1);
            Dist    = pi/sum(pi);
            pi      = diag(Dist);
            P_hat   = (pi^0.5*P2*pi^-0.5+pi^-0.5*P2'*pi^0.5)/2;
            
%         C2 = SpectralClustering(P2,cls_num);
%         re_ = ClusteringMeasure(gt,C2);
        re_our2 = baseline_spectral_onRW_acc(P_hat,cls_num,gt,1.5);


%     end
% end
