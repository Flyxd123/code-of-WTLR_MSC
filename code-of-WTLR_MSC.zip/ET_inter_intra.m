function [S E  conv err]=ET_inter_intra(Z,lambda,alpha)
%%min||J||_{w,*}+alpha*sum_({v=1,m}||P^{(v)}||_*+lambda*||E||_{2,1}
%% J=rotate(P)
%% s.t. Z=P+E
nV=length(Z);
N=size(Z{1},2);

  for k=1:nV
    J{k} = zeros(N,N);
    P{k} = zeros(N,N); %Z{2} = zeros(N,N);
    E{k} = zeros(N,N); %E{2} = zeros(size(X{k},1),N);
    Y{k} = zeros(N,N); %Y{2} = zeros(size(X{k},1),N);
    W{k} = zeros(N,N);
  end
 
  y = zeros(N*N*nV,1);
  p = zeros(N*N*nV,1);
  dim1 = N;dim2 = N;dim3 = nV;
  myNorm = 'tSVD_1';
  sX = [N, N, nV];
%set Default
parOP         =    false;
ABSTOL        =    1e-6;
RELTOL        =    1e-4;

Isconverg = 0;epson = 1e-7;
iter = 0;
mu1 = 10e-5; max_mu1 = 10e10; pho_mu1 = 1.9;
mu2 = 10e-5; max_mu2 = 10e10; pho_mu2 = 1.9;
while(Isconverg == 0)
    %%=======update E,Y=============%%

    tem_E=[];
    for k=1:nV
        tem = Z{k}-P{k}+Y{k}/mu1;
        tem_E=[tem_E;tem];
    end        
      [Econcat] = solve_l1l2(tem_E,lambda/mu1);
    for k=1:nV
        inx = (k-1)*N+1;
        E{k} = Econcat(inx:k*N,:);
        Y{k}=Y{k}+mu1*(Z{k}-P{k}-E{k});
    end 

    %%========updata P_hat(J)===%%
    T_tensor = cat(3, Z{:,:});
    J_tensor = cat(3,J{:,:});
    P_tensor = cat(3, P{:,:});
    E_tensor = cat(3, E{:,:});
    Y_tensor = cat(3, Y{:,:});
    W_tensor = cat(3, W{:,:});
    t = T_tensor(:);
    y = Y_tensor(:);
    w = W_tensor(:);

    p = P_tensor(:);
    e = E_tensor(:);
    
    [jp, objV] =wshrinkObj_weight(p-w/mu2,1/mu2,sX,1,3)   ;
     J_tensor = reshape(jp, sX);
        
     %%%%%%%%updata P%%%
     
     for k=1:nV
         tT1 = Z{k}-E{k}+Y{k}/mu1;
         tT2 =  J_tensor(:,:,k)+W{k}/mu2;
         tempP =(mu1*tT1+mu2*tT2)/(mu1+mu2);
         [U,sigma,V] = svd(tempP,'econ'); 
         sigma = diag(sigma);
         svp = length(find(sigma>alpha/(mu1+mu2)));
         if svp>=1
            sigma = sigma(1:svp)-alpha/(mu1+mu2);
         else
            svp = 1;
            sigma = 0;
         end
         P{k} = U(:,1:svp)*diag(sigma)*V(:,1:svp)';       
         W{k} =W{k}+mu2*(J_tensor(:,:,k)-P{k});
     end
   tP_tensor = cat(3, P{:,:});
    
    %5 update W
    
    %record the iteration information
    history.objval(iter+1)   =  objV;
    
    %% coverge condition
    Isconverg = 1;
    for k=1:nV
        if (norm(Z{k}-P{k}-E{k},inf)>epson)
            history.norm_Z = norm(Z{k}-P{k}-E{k},inf);
%             fprintf('    norm_Z %7.10f    ', history.norm_Z);
            Isconverg = 0;
        end        
        J{k} = J_tensor(:,:,k);
   end
   
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    conv(iter)=norm(T_tensor(:)-E_tensor(:)-tP_tensor(:),inf);
    err(iter) = norm(tP_tensor(:)-P_tensor(:),inf);
    mu1 = min(mu1*pho_mu1, max_mu1);
    mu2 = min(mu2*pho_mu2, max_mu2);
end

S = 0;
for k=1:nV
    S = S + abs(P{k})+abs(P{k}');
end